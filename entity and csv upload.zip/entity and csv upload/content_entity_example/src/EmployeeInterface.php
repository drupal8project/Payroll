<?php

namespace Drupal\content_entity_example;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\user\EntityOwnerInterface;
use Drupal\Core\Entity\EntityChangedInterface;

/**
 * Provides an interface defining a Employee entity.
 * @ingroup content_entity_example
 */
interface EmployeeInterface extends ContentEntityInterface, EntityOwnerInterface, EntityChangedInterface {

}

?>