<?php


namespace Drupal\bulk_user_registration;

use Drupal\content_entity_example\Entity\Employee;

class AddImportContent {
  public static function addImportContentItem($item, &$context){
	  
    $context['sandbox']['current_item'] = $item;
    $message = 'Creating ';
    $results = array();
	
	
	
    create_employee($item);
	//var_dump($item);die();
	
    $context['message'] = $message;
    $context['results'][] = $item;
  }
   function addImportContentItemCallback($success, $results, $operations) {
    // The 'success' parameter means no fatal PHP errors were detected. All
    // other error management should be handled using 'results'.
    if ($success) {
      $message = \Drupal::translation()->formatPlural(
        count($results),
        'One item processed.', '@count items processed.'
      );
    }
    else {
      $message = t('Finished with an error.');
    }
    drupal_set_message($message);
  }

}
// This function actually creates each item as a node as type 'Page'
   function create_employee($item) {
	
	
	
	// $entity_type = 'content_entity_example_employee';
	// $entity = entity_create($entity_type);
	// $wrapper = entity_metadata_wrapper($entity_type, $entity);
	// $wrapper->field_username->set($item['username']);
	// $wrapper->field_b->set($item['basic']);
	// $wrapper->field_hra->set($item['hra']);
	// $wrapper->field_m->set($item['medical ']);
	// $wrapper->field_p->set($item['professional']);
	// $wrapper->field_t->set($item['total']);
	// $wrapper->save();

  
  // $employee_data['field_u'] = $item['username'];
  // $employee_data['field_b'] = $item['basic'];
  // // Setting a simple textfield to add a unique ID so we can use it to query against if we want to manipulate this data again.
  // $employee_data['field_hr'] = $item['hra'];
  // $employee_data['field_m'] = $item['medical'];
  // $employee_data['field_p'] = $item['professional'];
  // $employee_data['field_t'] = $item['total'];
  

	//$a = $item['id'];
	//0var_dump($item);die();
  // $account = \Drupal\user\Entity\User::load($a); // pass your uid
   //$user=user_load($a);
   //$name=$user->name;
   //$name = $account->getUsername();
   //var_dump($name);die();
  
	 $id = $item['id'];
	 $account = \Drupal\user\Entity\User::load($id); // pass your uid
     $name = $account->getUsername();
  
  
  
  $employee = Employee::create([
  
  'field_i'  => $item['id'],
  'field_u'  => $name,
  'field_b'  => $item['basic'],
  'field_hra' => $item['hra'],
  'field_m'  => $item['medical'],
  'field_p'  => $item['professional'],
  'field_t'  => $item['total']
  
  ]);
 // $employee->field_u->set($name);
  //var_dump($employee);die();
  $employee->save();
  
  //var_dump($employee->get('field_u')->getValue());die();
  //$employee->setPublished(TRUE);
  
   // 
} 
  
  
  
  
 
?>