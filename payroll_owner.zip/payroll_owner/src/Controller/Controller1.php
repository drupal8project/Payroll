<?php

/**
 * @file
 * Contains \Drupal\payroll_owner\Controller\Controller1.
 */
namespace Drupal\payroll_owner\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller1 extends ControllerBase {
	
  public function content() {
    
	return array(
      '#type' => 'markup',
      '#markup' => $this->t('Welcome Admin, How r u?'),
    );
  }
}