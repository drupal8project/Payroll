<?php

/**
 * @file
 * Contains \Drupal\payroll_owner\Controller\Controller3.
 */
namespace Drupal\payroll_owner\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller3 extends ControllerBase {
  public function content() {
    return new RedirectResponse(\Drupal::url('route.name'));
  }
}