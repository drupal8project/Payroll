<?php

/**
 * @file
 * Contains \Drupal\payroll_user\Controller\UserController.
 */
namespace Drupal\payroll_user\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

class UserController extends ControllerBase {
	
	
	/**
	* Drupal\Core\Form\AccountProxy definition.
	*
	* @var \Drupal\Core\Form\AccountProxy
	*/
	protected $currentUser;

	/**
	* {@inheritdoc}
	*/
	public function __construct(AccountProxyInterface $current_user) {
		$this->currentUser = $current_user;
	}
	/**
	* {@inheritdoc}
	*/
	public static function create(ContainerInterface $container) {
		return new static(
			$container->get('current_user')
		);
	}
	
	public function myProfile() {
		
	global $base_url;
    $user = \Drupal::currentUser();
    $path = '/mypayroll/'. $user->id();

    $response = new \Symfony\Component\HttpFoundation\RedirectResponse($base_url . $path);
    return $response->send();
	

	}
		
	public function content() {
	  
		return array(
			'#type' => 'markup',
			'#markup' => $this->t('')
		);
	}
	
}