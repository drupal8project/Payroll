<?php

/**
 * @file
 * Contains \Drupal\payroll_user\Controller\Controller6.
 */
namespace Drupal\payroll_user\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller6 extends ControllerBase {
  public function content() {
    return array(
      '#type' => 'markup',
      '#markup' => $this->t('Employee Dashboard'),
    );
  }
}