<?php

/**
 * @file
 * Contains \Drupal\payroll_admin\Controller\Controller5.
 */
namespace Drupal\payroll_admin\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller5 extends ControllerBase {
  public function content() {
   $url = "../admin/people/create";
  $response = new Symfony\Component\HttpFoundation\RedirectResponse($url);
  $response->send();
  return;
  }
}