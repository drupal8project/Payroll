<?php

/**
 * @file
 * Contains \Drupal\payroll_user\Controller\Controller7.
 */
namespace Drupal\payroll_user\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller7 extends ControllerBase {
	
  public function content() {
    
	return array(
      '#type' => 'markup',
      '#markup' => $this->t('User Profile'),
    );
  
  }
}