<?php

/**
 * @file
 * Contains \Drupal\payroll_user\Controller\Controller8.
 */
namespace Drupal\payroll_user\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller8 extends ControllerBase {
	
  public function content() {
    
	return new RedirectResponse(\Drupal::url('https://www.google.com'));
  }
}