<?php

/**
 * @file
 * Contains \Drupal\payroll_admin\Controller\Controller1.
 */
namespace Drupal\payroll_admin\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller1 extends ControllerBase {
	
  public function content() {
    
	return array(
      '#type' => 'markup',
      '#markup' => $this->t('Welcome Admin, How r u?'),
    );
  }
}