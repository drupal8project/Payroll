<?php

/**
 * @file
 * Contains \Drupal\payroll_admin\Controller\Controller3.
 */
namespace Drupal\payroll_admin\Controller;

use Drupal\Core\Controller\ControllerBase;

class Controller3 extends ControllerBase {
  public function content() {
    return new RedirectResponse(\Drupal::url('route.name'));
  }
}