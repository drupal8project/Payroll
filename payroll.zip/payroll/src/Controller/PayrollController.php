<?php

namespace Drupal\payroll\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller
 */
class PayrollController extends ControllerBase {
    
    /**
     * Returns String Message
     */
	public function demo() {		
		
	}
}