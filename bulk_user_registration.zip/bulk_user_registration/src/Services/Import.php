<?php
namespace Drupal\bulk_user_registration\Services;

use Drupal\file\Entity\File;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class Import.
 */
class Import {
	
  public  function createEntity(){
  
	  $filepath = "public://csv/";

	  $handle = @fopen($filepath, "r");
	  // start count of imports for this upload
	  $send_counter = 0;
	  
	  $query = \Drupal::entityQuery('user');
	  $uids = $query->execute();

	  while ($row = fgetcsv($handle, $line_max, ',')) {
		foreach($row as $key=>$value) {
		  
		 $ids = \Drupal::entityQuery('user')->condition('name', $row[0])->range(0, 1)->execute();
		 
		if(!empty($ids)){
		  $pids = \Drupal::entityQuery('employee')->condition('name', $row[0])->range(0, 1)->execute();
		  if(empty($ids)){
			$payroll = \Drupal::entityTypeManager()->getStorage('payroll')->create(
			  [
			  'type' => 'employee',
			  //'employee_id'=> $row[0],
			  'basic_salary' => $row[1],
			  'hra' => $row[2],
			  'medical_allowance' => $row[3],
			  'professional_tax'=>$row[4],
			  'total_salary'=>row[5]
			  ]
			);
			$payroll->save();
		  }
		}
	  }
	}
    //$response = new RedirectResponse('/drupal-8.6.10/content_entity_example_employee/list');
    //$response->send();

  } 
} 
?>	  