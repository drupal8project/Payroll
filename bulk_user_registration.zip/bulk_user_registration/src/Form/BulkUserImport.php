<?php

namespace Drupal\bulk_user_registration\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\bulk_user_registration\Services\Import;


/**
 * Configure Content Import settings for this site.
 */
class BulkUserImport extends FormBase {


 /**
   * @var Import $Import
   */
  protected $import;

  /**
   * Class constructor.
   */
  public function __construct(Import $import) {
    $this->import = $import;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('bulk_user_registration.demo')
    );
  }


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bulk_user_registration';
  }

  /**
   * User Import Form.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
	  

   $form['csv_file'] = array(
              '#type' => 'managed_file',
              '#upload_location' => 'public://csv',
              '#title' => 'CSV File',
              '#upload_validators' => array(
                  'file_validate_extensions' => array('csv')),
          );
          $form['actions']['#type'] = 'actions';
          $form['actions']['submit'] = array(
              '#type' => 'submit',
              '#value' => $this->t('Save'),
              '#button_type' => 'primary',
          );
    return $form;
   
  }


  public function validateForm(array &$form, FormStateInterface $form_state) {
	
	 
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->import->createEntity($form_state);
  }
}

 
  



  

?>